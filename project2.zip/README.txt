1.
Users: {{UserID}, country, location, bidder-rating, seller-rating}
Items: {{ItemID}, UserID, name, first bid, buy price, number of bids, started, ends, description}
ItemCategory: {ItemID, Category}
Bids: {UserID, ItemID, Time, Amount}

{} indicates a key

2. Aside from those that include keys, there are no dependencies between tables.

3.Yes
4.Yes

For some reason our 2nd query does not produce the correct output, but we
are fairly sure our query is correct, so the items database may not be correct.
Our theory is that there are users with multiple addresses, which is a case
which we did not anticipate and we had no time to fix our implementation to
cover this case.
