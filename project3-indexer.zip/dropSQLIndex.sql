DROP INDEX SpatialIndex ON SpatialTable;

DROP TABLE IF EXISTS SpatialTable;